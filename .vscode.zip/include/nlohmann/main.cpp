#include <iostream>
#include <fstream>
#include <vector>
#include <unordered_map>
#include <map>
#include <set>
#include <queue>
#include <algorithm>
#include <limits>
#include <stack>
#include <climits>
#include <iomanip>
#include <ctime>
#include <random>
#include <sstream>
#include <cmath>
#include <tuple>

// For systems that don't have M_PI defined
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

using namespace std;

// Traffic factor related structures and constants
struct TrafficInfo {
double factor; // Multiplier for base distance
string condition; // Light, Moderate, Heavy, Severe
time_t timestamp; // When this traffic info was last updated
};

// Geographic coordinate structure
struct Coordinate {
double lat, lng;
Coordinate(double latitude = 0, double longitude = 0) : lat(latitude), lng(longitude) {}
};

// Traffic conditions mapping
const unordered_map<string, pair<double, double>> TRAFFIC_RANGES = {
{"Light", {1.0, 1.2}},
{"Moderate", {1.2, 1.5}},
{"Heavy", {1.5, 2.0}},
{"Severe", {2.0, 3.0}}
};

// Global graph data structures
unordered_map<string, vector<pair<string, int>>> adjList;
unordered_map<string, unordered_map<string, int>> adjMatrix;
unordered_map<string, Coordinate> cityCoordinates;
unordered_map<string, int> cityIndices;
vector<string> indexToCity;

// Traffic data structure
unordered_map<string, unordered_map<string, TrafficInfo>> trafficData;

// For Floyd-Warshall
vector<vector<int>> distFW;
vector<vector<string>> nextFW;

// For MST
vector<tuple<int, string, string>> mstEdges;

// Traffic generation parameters
const int UPDATE_INTERVAL = 900; // 15 minutes in seconds
const double TRAFFIC_VARIATION = 0.2; // Maximum random variation

// Auto-save and backup functionality
const string AUTO_SAVE_FILE = "auto_save_graph.json";

// Random number generator (proper initialization)
random_device rd;
mt19937 gen(rd());

// Function declarations
double calculateDistance(const Coordinate& coord1, const Coordinate& coord2);
int getCityIndex(const string& city);
double generateTrafficFactor(const pair<double, double>& range);
string determineTrafficCondition(const string& from, const string& to, time_t currentTime);
void updateTrafficInfo();
int getTrafficAdjustedDistance(const string& from, const string& to, int baseDistance);
void autoSaveGraph();
void loadGraphFromJSON(const string& filename);
void addCity(const string& cityName, double lat, double lng);
void addRoute(const string& from, const string& to, int distance);
void addRoute(const string& from, const string& to); // Overloaded version
pair<vector<string>, int> dijkstraWithTraffic(const string& source, const string& destination);
string getComprehensiveTrafficReport();
void initializeFloydWarshall();
vector<string> getPathFW(const string& start, const string& end);
void primMST(const string& startCity);
pair<vector<string>, int> optimizeTravelPlan(const vector<string>& citiesToVisit);
void printPath(const vector<string>& path, int distance);
void listCities();
void displayMenu();
void initializeGraph();
void generateTrafficReport();
void displayTrafficConditions();

// Calculate distance between two coordinates using Haversine formula
double calculateDistance(const Coordinate& coord1, const Coordinate& coord2) {
const double R = 6371.0; // Earth radius in kilometers

double lat1Rad = coord1.lat * M_PI / 180.0;
double lat2Rad = coord2.lat * M_PI / 180.0;
double deltaLatRad = (coord2.lat - coord1.lat) * M_PI / 180.0;
double deltaLngRad = (coord2.lng - coord1.lng) * M_PI / 180.0;

double a = sin(deltaLatRad / 2) * sin(deltaLatRad / 2) +
cos(lat1Rad) * cos(lat2Rad) *
sin(deltaLngRad / 2) * sin(deltaLngRad / 2);
double c = 2 * atan2(sqrt(a), sqrt(1 - a));

return R * c;
}

// Helper function to get city index
int getCityIndex(const string& city) {
if (cityIndices.find(city) == cityIndices.end()) {
cityIndices[city] = indexToCity.size();
indexToCity.push_back(city);
}
return cityIndices[city];
}

// Generate a random traffic factor within a range
double generateTrafficFactor(const pair<double, double>& range) {
uniform_real_distribution<double> dis(range.first, range.second);
return dis(gen);
}

// Determine traffic condition based on time of day and route characteristics
string determineTrafficCondition(const string& from, const string& to, time_t currentTime) {
tm* timeinfo = localtime(&currentTime);
int hour = timeinfo->tm_hour;

// Simulate rush hours (7-9 AM and 4-6 PM)
bool isRushHour = (hour >= 7 && hour <= 9) || (hour >= 16 && hour <= 18);
bool isMajorRoute = adjMatrix[from][to] > 200; // Routes longer than 200 km
bool isWeekend = timeinfo->tm_wday == 0 || timeinfo->tm_wday == 6;

vector<string> possibleConditions;

if (isWeekend) {
possibleConditions = {"Light", "Moderate"};
} else if (isRushHour && isMajorRoute) {
possibleConditions = {"Heavy", "Severe"};
} else if (isRushHour) {
possibleConditions = {"Moderate", "Heavy"};
} else if (isMajorRoute) {
possibleConditions = {"Light", "Moderate", "Heavy"};
} else {
possibleConditions = {"Light", "Moderate"};
}

uniform_int_distribution<int> dis(0, possibleConditions.size() - 1);
return possibleConditions[dis(gen)];
}

// Update traffic information for all routes
void updateTrafficInfo() {
time_t currentTime = time(nullptr);

for (const auto& from : adjList) {
for (const auto& to : from.second) {
// Check if traffic info needs updating
if (trafficData[from.first][to.first].timestamp + UPDATE_INTERVAL < currentTime) {
string condition = determineTrafficCondition(from.first, to.first, currentTime);
double factor = generateTrafficFactor(TRAFFIC_RANGES.at(condition));

// Add some random variation
uniform_real_distribution<double> variation(-TRAFFIC_VARIATION, TRAFFIC_VARIATION);
factor *= (1.0 + variation(gen));

trafficData[from.first][to.first] = {
factor,
condition,
currentTime
};
}
}
}
}

// Get traffic-adjusted distance between two cities
int getTrafficAdjustedDistance(const string& from, const string& to, int baseDistance) {
if (trafficData.find(from) != trafficData.end() &&
trafficData[from].find(to) != trafficData[from].end()) {
return static_cast<int>(baseDistance * trafficData[from][to].factor);
}
return baseDistance;
}

// Initialize graph with sample data
void initializeGraph() {
// Sample cities with coordinates (India)
addCity("Delhi", 28.6139, 77.2090);
addCity("Mumbai", 19.0760, 72.8777);
addCity("Bangalore", 12.9716, 77.5946);
addCity("Chennai", 13.0827, 80.2707);
addCity("Kolkata", 22.5726, 88.3639);
addCity("Hyderabad", 17.3850, 78.4867);
addCity("Pune", 18.5204, 73.8567);
addCity("Ahmedabad", 23.0225, 72.5714);

// Add sample routes
addRoute("Delhi", "Mumbai");
addRoute("Delhi", "Bangalore");
addRoute("Delhi", "Chennai");
addRoute("Delhi", "Kolkata");
addRoute("Mumbai", "Bangalore");
addRoute("Mumbai", "Pune");
addRoute("Mumbai", "Ahmedabad");
addRoute("Bangalore", "Chennai");
addRoute("Bangalore", "Hyderabad");
addRoute("Chennai", "Hyderabad");
addRoute("Kolkata", "Chennai");

// Initialize Floyd-Warshall
initializeFloydWarshall();

cout << "Graph initialized with sample Indian cities!" << endl;
}

// Add new city with coordinates
void addCity(const string& cityName, double lat, double lng) {
if (cityCoordinates.find(cityName) != cityCoordinates.end()) {
cout << "City " << cityName << " already exists!" << endl;
return;
}

cityCoordinates[cityName] = Coordinate(lat, lng);
getCityIndex(cityName);

cout << "Added city: " << cityName << " at (" << lat << ", " << lng << ")" << endl;
}

// Add route between two cities with manual distance
void addRoute(const string& from, const string& to, int distance) {
if (cityCoordinates.find(from) == cityCoordinates.end() ||
cityCoordinates.find(to) == cityCoordinates.end()) {
cout << "One or both cities don't exist. Please add cities first." << endl;
return;
}

// Check if route already exists
if (adjMatrix[from].find(to) != adjMatrix[from].end()) {
cout << "Route between " << from << " and " << to << " already exists!" << endl;
return;
}

// Add to adjacency list and matrix
adjList[from].emplace_back(to, distance);
adjList[to].emplace_back(from, distance);
adjMatrix[from][to] = distance;
adjMatrix[to][from] = distance;

// Initialize traffic data
trafficData[from][to] = {1.0, "Light", time(nullptr)};
trafficData[to][from] = {1.0, "Light", time(nullptr)};

cout << "Added route: " << from << " ↔ " << to << " (" << distance << " km)" << endl;
}

// Add route between two cities with automatic distance calculation
void addRoute(const string& from, const string& to) {
if (cityCoordinates.find(from) == cityCoordinates.end() ||
cityCoordinates.find(to) == cityCoordinates.end()) {
cout << "One or both cities don't exist. Please add cities first." << endl;
return;
}

// Check if route already exists
if (adjMatrix[from].find(to) != adjMatrix[from].end()) {
cout << "Route between " << from << " and " << to << " already exists!" << endl;
return;
}

// Calculate distance automatically
int distance = static_cast<int>(calculateDistance(cityCoordinates[from], cityCoordinates[to]));

// Add to adjacency list and matrix
adjList[from].emplace_back(to, distance);
adjList[to].emplace_back(from, distance);
adjMatrix[from][to] = distance;
adjMatrix[to][from] = distance;

// Initialize traffic data
trafficData[from][to] = {1.0, "Light", time(nullptr)};
trafficData[to][from] = {1.0, "Light", time(nullptr)};

cout << "Added route: " << from << " ↔ " << to << " (" << distance << " km)" << endl;
}

// Modified Dijkstra's Algorithm with traffic consideration
pair<vector<string>, int> dijkstraWithTraffic(const string& source, const string& destination) {
updateTrafficInfo(); // Update traffic info before pathfinding

priority_queue<pair<int, string>, vector<pair<int, string>>, greater<pair<int, string>>> pq;
unordered_map<string, int> dist;
unordered_map<string, string> prev;

for (const auto& city : adjList) {
dist[city.first] = INT_MAX;
}

dist[source] = 0;
pq.push({0, source});

while (!pq.empty()) {
string u = pq.top().second;
int current_dist = pq.top().first;
pq.pop();

if (current_dist > dist[u]) continue;

for (const auto& neighbor : adjList[u]) {
string v = neighbor.first;
int baseWeight = neighbor.second;
int trafficAdjustedWeight = getTrafficAdjustedDistance(u, v, baseWeight);

if (dist[v] > dist[u] + trafficAdjustedWeight) {
dist[v] = dist[u] + trafficAdjustedWeight;
prev[v] = u;
pq.push({dist[v], v});
}
}
}

// Reconstruct path
vector<string> path;
if (dist[destination] == INT_MAX) {
return {path, -1}; // No path exists
}

for (string at = destination; at != ""; at = prev[at]) {
path.push_back(at);
}
reverse(path.begin(), path.end());

return {path, dist[destination]};
}

// Get comprehensive traffic report
string getComprehensiveTrafficReport() {
updateTrafficInfo();

stringstream ss;
ss << "\n===== COMPREHENSIVE TRAFFIC REPORT =====\n";
time_t now = time(nullptr);
ss << "Report generated at: " << ctime(&now);
ss << "\nTraffic Conditions Summary:\n";

map<string, int> conditionCounts;
set<pair<string, string>> reportedRoutes;

for (const auto& from : trafficData) {
for (const auto& to : from.second) {
if (reportedRoutes.find({from.first, to.first}) == reportedRoutes.end() &&
reportedRoutes.find({to.first, from.first}) == reportedRoutes.end()) {

const auto& info = to.second;
conditionCounts[info.condition]++;

ss << "\n" << from.first << " ↔ " << to.first << ":\n";
ss << " Distance: " << adjMatrix[from.first][to.first] << " km\n";
ss << " Condition: " << info.condition << " (Factor: " << fixed << setprecision(2) << info.factor << "x)\n";
ss << " Adjusted Distance: " << getTrafficAdjustedDistance(from.first, to.first, adjMatrix[from.first][to.first]) << " km\n";

reportedRoutes.insert({from.first, to.first});
}
}
}

ss << "\n--- SUMMARY ---\n";
for (const auto& count : conditionCounts) {
ss << count.first << " traffic: " << count.second << " routes\n";
}

return ss.str();
}

// Generate and display traffic report
void generateTrafficReport() {
cout << getComprehensiveTrafficReport() << endl;
}

// Display current traffic conditions
void displayTrafficConditions() {
updateTrafficInfo();

cout << "\n===== CURRENT TRAFFIC CONDITIONS =====\n";
set<pair<string, string>> reportedRoutes;

for (const auto& from : trafficData) {
for (const auto& to : from.second) {
if (reportedRoutes.find({from.first, to.first}) == reportedRoutes.end() &&
reportedRoutes.find({to.first, from.first}) == reportedRoutes.end()) {

const auto& info = to.second;
cout << from.first << " ↔ " << to.first << ": "
<< info.condition << " (Factor: " << fixed << setprecision(2)
<< info.factor << "x)" << endl;

reportedRoutes.insert({from.first, to.first});
}
}
}
}

// Floyd-Warshall Algorithm with traffic considerations
void initializeFloydWarshall() {
updateTrafficInfo(); // Update traffic before initialization

int n = indexToCity.size();
distFW.assign(n, vector<int>(n, INT_MAX));
nextFW.assign(n, vector<string>(n, ""));

for (int i = 0; i < n; i++) {
distFW[i][i] = 0;
}

for (const auto& from : adjList) {
int u = getCityIndex(from.first);
for (const auto& to : from.second) {
int v = getCityIndex(to.first);
// Use traffic-adjusted distance
distFW[u][v] = getTrafficAdjustedDistance(from.first, to.first, to.second);
nextFW[u][v] = to.first;
}
}

for (int k = 0; k < n; k++) {
for (int i = 0; i < n; i++) {
for (int j = 0; j < n; j++) {
if (distFW[i][k] != INT_MAX && distFW[k][j] != INT_MAX &&
distFW[i][j] > distFW[i][k] + distFW[k][j]) {
distFW[i][j] = distFW[i][k] + distFW[k][j];
nextFW[i][j] = nextFW[i][k];
}
}
}
}
}

vector<string> getPathFW(const string& start, const string& end) {
vector<string> path;

if (cityIndices.find(start) == cityIndices.end() ||
cityIndices.find(end) == cityIndices.end()) {
return path;
}

int u = getCityIndex(start);
int v = getCityIndex(end);

if (nextFW[u][v].empty()) {
return path;
}

path.push_back(start);
string current = start;
while (current != end) {
u = getCityIndex(current);
current = nextFW[u][v];
path.push_back(current);
}

return path;
}

// Modified Prim's Algorithm for MST with traffic considerations
void primMST(const string& startCity) {
updateTrafficInfo(); // Update traffic before MST calculation

priority_queue<tuple<int, string, string>,
vector<tuple<int, string, string>>,
greater<tuple<int, string, string>>> pq;

unordered_map<string, bool> inMST;
mstEdges.clear();

for (const auto& city : adjList) {
inMST[city.first] = false;
}

inMST[startCity] = true;
for (const auto& neighbor : adjList[startCity]) {
int trafficAdjustedWeight = getTrafficAdjustedDistance(startCity, neighbor.first, neighbor.second);
pq.push(make_tuple(trafficAdjustedWeight, startCity, neighbor.first));
}

while (!pq.empty()) {
int weight = get<0>(pq.top());
string u = get<1>(pq.top());
string v = get<2>(pq.top());
pq.pop();

if (inMST[v]) continue;

inMST[v] = true;
mstEdges.push_back(make_tuple(weight, u, v));

for (const auto& neighbor : adjList[v]) {
if (!inMST[neighbor.first]) {
int trafficAdjustedWeight = getTrafficAdjustedDistance(v, neighbor.first, neighbor.second);
pq.push(make_tuple(trafficAdjustedWeight, v, neighbor.first));
}
}
}
}

// Modified Travel Plan Optimization with traffic considerations
pair<vector<string>, int> optimizeTravelPlan(const vector<string>& citiesToVisit) {
if (citiesToVisit.empty()) return {vector<string>(), 0};

updateTrafficInfo(); // Update traffic before planning

// Build MST for the subgraph
primMST(citiesToVisit[0]);

// Create a map of connections from MST
unordered_map<string, vector<string>> mstConnections;
for (const auto& edge : mstEdges) {
string u = get<1>(edge);
string v = get<2>(edge);
mstConnections[u].push_back(v);
mstConnections[v].push_back(u);
}

// Perform DFS on MST to get traversal order
vector<string> traversalOrder;
stack<string> s;
unordered_map<string, bool> visited;

s.push(citiesToVisit[0]);
visited[citiesToVisit[0]] = true;

while (!s.empty()) {
string current = s.top();
s.pop();
traversalOrder.push_back(current);

for (const string& neighbor : mstConnections[current]) {
if (!visited[neighbor]) {
visited[neighbor] = true;
s.push(neighbor);
}
}
}

// Connect cities using traffic-aware shortest paths
vector<string> fullPath;
int totalDistance = 0;

for (size_t i = 0; i < traversalOrder.size() - 1; i++) {
auto result = dijkstraWithTraffic(traversalOrder[i], traversalOrder[i+1]);
if (result.second == -1) {
return {vector<string>(), -1};
}

for (size_t j = 0; j < result.first.size() - 1; j++) {
fullPath.push_back(result.first[j]);
}
totalDistance += result.second;
}
fullPath.push_back(traversalOrder.back());

return {fullPath, totalDistance};
}

// Utility function to print a path with detailed information
void printPath(const vector<string>& path, int distance) {
if (path.empty()) {
cout << "No path exists!" << endl;
return;
}

cout << "\n===== PATH DETAILS =====\n";
cout << "Route: ";
for (size_t i = 0; i < path.size(); i++) {
if (i > 0) cout << " → ";
cout << path[i];
}
cout << "\nTotal distance: " << distance << " km" << endl;

// Show segment details
cout << "\nSegment breakdown:\n";
for (size_t i = 0; i < path.size() - 1; i++) {
string from = path[i];
string to = path[i + 1];
int baseDistance = adjMatrix[from][to];
int adjustedDistance = getTrafficAdjustedDistance(from, to, baseDistance);

if (trafficData[from].find(to) != trafficData[from].end()) {
const auto& traffic = trafficData[from][to];
cout << " " << from << " → " << to << ": "
<< baseDistance << " km (Traffic: " << traffic.condition
<< ", Adjusted: " << adjustedDistance << " km)" << endl;
} else {
cout << " " << from << " → " << to << ": " << baseDistance << " km" << endl;
}
}
}

// List all cities
void listCities() {
cout << "\n===== AVAILABLE CITIES =====\n";
if (cityCoordinates.empty()) {
cout << "No cities available." << endl;
return;
}

cout << "Total cities: " << cityCoordinates.size() << endl;
for (const auto& city : cityCoordinates) {
cout << "• " << city.first << " (" << fixed << setprecision(4)
<< city.second.lat << ", " << city.second.lng << ")" << endl;
}
}


// Enhanced menu system
void displayMenu() {
cout << "\n========== TRAFFIC-AWARE ROUTING SYSTEM ==========\n";
cout << "1. Find shortest path (Dijkstra with Traffic)\n";
cout << "2. Find shortest path (Floyd-Warshall)\n";
cout << "3. Optimize travel plan for multiple cities\n";
cout << "4. Get comprehensive traffic report\n";
cout << "5. Update traffic information\n";
cout << "6. List all available cities\n";
cout << "7. Add new city\n";
cout << "8. Add new route\n";
cout << "9. Display current traffic conditions\n";
cout << "10. Exit\n";
cout << "================================================\n";
cout << "Enter your choice: ";
}
// ======================== WEB COMMAND HANDLER ========================
void processWebCommand(const string& command, const vector<string>& args) {
    if (command == "GET_ROUTE") {
        if (args.size() < 2) {
            cout << "ERROR|Missing start or end city" << endl;
            return;
        }
        auto result = dijkstraWithTraffic(args[0], args[1]);
        cout << "ROUTE|";
        for (size_t i = 0; i < result.first.size(); ++i) {
            cout << result.first[i];
            if (i != result.first.size() - 1) cout << "→";
        }
        cout << "|" << result.second << endl;
    }
    else if (command == "GET_TRAFFIC_REPORT") {
        stringstream ss;
        set<pair<string, string>> reportedRoutes;
        for (const auto& from : trafficData) {
            for (const auto& to : from.second) {
                if (reportedRoutes.count({from.first, to.first}) == 0 &&
                    reportedRoutes.count({to.first, from.first}) == 0) {
                    const auto& info = to.second;
                    ss << from.first << " → " << to.first
                       << ": " << info.condition
                       << " (Factor: " << fixed << setprecision(2)
                       << info.factor << "x)\n";
                    reportedRoutes.insert({from.first, to.first});
                }
            }
        }
        cout << "TRAFFIC_REPORT|" << ss.str() << endl;
    }
    else if (command == "LIST_CITIES") {
        stringstream ss;
        for (const auto& city : cityCoordinates) {
            ss << city.first << " (" << fixed << setprecision(4)
               << city.second.lat << "," << city.second.lng << ")\n";
        }
        cout << "CITY_LIST|" << ss.str() << endl;
    }
    else {
        cout << "ERROR|Unknown command" << endl;
    }
}

int main(int argc, char* argv[]) {
    cout << "Initializing Traffic-Aware Routing System..." << endl;
    initializeGraph();

    if (argc > 1 && string(argv[1]) == "--web") {
        string input;
        while (getline(cin, input)) {
            size_t pos = input.find('|');
            string command = input.substr(0, pos);
            vector<string> args;

            while (pos != string::npos) {
                input = input.substr(pos + 1);
                pos = input.find('|');
                args.push_back(input.substr(0, pos));
            }

            processWebCommand(command, args);
        }
    } else {
        // ORIGINAL INTERACTIVE MENU
        int choice;
        string start, end, newCity;
        double lat, lng;
        int distance;
        vector<string> cities;

        while (true) {
            displayMenu();
            cin >> choice;
            cin.ignore(); // Clear the input buffer

            switch (choice) {
                case 1: {
                    cout << "Enter start city: ";
                    getline(cin, start);
                    cout << "Enter destination city: ";
                    getline(cin, end);

                    auto result = dijkstraWithTraffic(start, end);
                    printPath(result.first, result.second);
                    break;
                }
                case 2: {
                    cout << "Enter start city: ";
                    getline(cin, start);
                    cout << "Enter destination city: ";
                    getline(cin, end);

                    vector<string> path = getPathFW(start, end);
                    int totalDistance = 0;
                    for (size_t i = 0; i < path.size() - 1; i++) {
                        totalDistance += getTrafficAdjustedDistance(path[i], path[i+1],
                                                adjMatrix[path[i]][path[i+1]]);
                    }
                    printPath(path, totalDistance);
                    break;
                }
                case 3: {
                    cout << "Enter number of cities to visit: ";
                    int n;
                    cin >> n;
                    cin.ignore();

                    cities.clear();
                    for (int i = 0; i < n; i++) {
                        cout << "Enter city " << (i+1) << ": ";
                        string city;
                        getline(cin, city);
                        cities.push_back(city);
                    }

                    auto result = optimizeTravelPlan(cities);
                    if (result.second != -1) {
                        cout << "\nOptimized travel plan:\n";
                        printPath(result.first, result.second);
                    } else {
                        cout << "Could not create travel plan for the given cities." << endl;
                    }
                    break;
                }
                case 4: {
                    generateTrafficReport();
                    break;
                }
                case 5: {
                    updateTrafficInfo();
                    cout << "Traffic information updated successfully!" << endl;
                    break;
                }
                case 6: {
                    listCities();
                    break;
                }
                case 7: {
                    cout << "Enter city name: ";
                    getline(cin, newCity);
                    cout << "Enter latitude: ";
                    cin >> lat;
                    cout << "Enter longitude: ";
                    cin >> lng;
                    cin.ignore();

                    addCity(newCity, lat, lng);
                    break;
                }
                case 8: {
                    cout << "Enter start city: ";
                    getline(cin, start);
                    cout << "Enter end city: ";
                    getline(cin, end);
                    cout << "Enter distance (km) or 0 for auto-calculation: ";
                    cin >> distance;
                    cin.ignore();

                    if (distance == 0) {
                        addRoute(start, end);
                    } else {
                        addRoute(start, end, distance);
                    }
                    break;
                }
                case 9: {
                    displayTrafficConditions();
                    break;
                }
                case 10: {
                    cout << "Thank you for using the Traffic-Aware Routing System!" << endl;
                    return 0;
                }
                default: {
                    cout << "Invalid choice! Please try again." << endl;
                    break;
                }
            }

            cout << "\nPress Enter to continue...";
            cin.get();
        }
    }

    return 0;
}
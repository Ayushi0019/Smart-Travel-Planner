#include <iostream>
#include <fstream>
#include <vector>
#include <unordered_map>
#include <map>
#include <set>
#include <queue>
#include <algorithm>
#include <limits>
#include <stack>
#include <climits>
#include <iomanip>
#include <ctime>
#include <random>
#include <sstream>
#include "json.hpp"
#include <tuple>

using namespace std;
using json = nlohmann::json;

// Traffic factor related structures and constants
struct TrafficInfo {
    double factor;     // Multiplier for base distance
    string condition;  // Light, Moderate, Heavy, Severe
    time_t timestamp; // When this traffic info was last updated
};

// Traffic conditions mapping
const unordered_map<string, pair<double, double>> TRAFFIC_RANGES = {
    {"Light", {1.0, 1.2}},
    {"Moderate", {1.2, 1.5}},
    {"Heavy", {1.5, 2.0}},
    {"Severe", {2.0, 3.0}}
};

// Graph data structures
unordered_map<string, vector<pair<string, int>>> adjList;
unordered_map<string, unordered_map<string, int>> adjMatrix;
unordered_map<string, pair<double, double>> cityCoordinates;
unordered_map<string, int> cityIndices;
vector<string> indexToCity;

// Traffic data structure
unordered_map<string, unordered_map<string, TrafficInfo>> trafficData;

// For Floyd-Warshall
vector<vector<int>> distFW;
vector<vector<string>> nextFW;

// For MST
vector<tuple<int, string, string>> mstEdges;

// Traffic generation parameters
const int UPDATE_INTERVAL = 900; // 15 minutes in seconds
const double TRAFFIC_VARIATION = 0.2; // Maximum random variation

// Helper function to get city index
int getCityIndex(const string& city) {
    if (cityIndices.find(city) == cityIndices.end()) {
        cityIndices[city] = indexToCity.size();
        indexToCity.push_back(city);
    }
    return cityIndices[city];
}

// Generate a random traffic factor within a range
double generateTrafficFactor(const pair<double, double>& range) {
    double span = range.second - range.first;
    return range.first + (static_cast<double>(rand()) / RAND_MAX) * span;
}

// Determine traffic condition based on time of day and random factors
string determineTrafficCondition(const string& from, const string& to, time_t currentTime) {
    tm* timeinfo = localtime(&currentTime);
    int hour = timeinfo->tm_hour;
    
    // Simulate rush hours (7-9 AM and 4-6 PM)
    bool isRushHour = (hour >= 7 && hour <= 9) || (hour >= 16 && hour <= 18);
    bool isMajorRoute = adjMatrix[from][to] > 100; // Routes longer than 100 units
    
    vector<string> possibleConditions;
    if (isRushHour && isMajorRoute) {
        possibleConditions = {"Heavy", "Severe"};
    } else if (isRushHour) {
        possibleConditions = {"Moderate", "Heavy"};
    } else if (isMajorRoute) {
        possibleConditions = {"Light", "Moderate", "Heavy"};
    } else {
        possibleConditions = {"Light", "Moderate"};
    }
    
    return possibleConditions[rand() % possibleConditions.size()];
}

// Update traffic information for all routes
void updateTrafficInfo() {
    time_t currentTime = time(nullptr);
    
    for (const auto& from : adjList) {
        for (const auto& to : from.second) {
            // Check if traffic info needs updating
            if (trafficData[from.first][to.first].timestamp + UPDATE_INTERVAL < currentTime) {
                string condition = determineTrafficCondition(from.first, to.first, currentTime);
                double factor = generateTrafficFactor(TRAFFIC_RANGES.at(condition));
                
                // Add some random variation
                factor *= (1.0 + (((double)rand() / RAND_MAX) * 2 - 1) * TRAFFIC_VARIATION);
                
                trafficData[from.first][to.first] = {
                    factor,
                    condition,
                    currentTime
                };
            }
        }
    }
}

// Get traffic-adjusted distance between two cities
int getTrafficAdjustedDistance(const string& from, const string& to, int baseDistance) {
    if (trafficData.find(from) != trafficData.end() && 
        trafficData[from].find(to) != trafficData[from].end()) {
        return static_cast<int>(baseDistance * trafficData[from][to].factor);
    }
    return baseDistance;
}

// Load graph from JSON
void loadGraphFromJSON(const string& filename) {
    ifstream inFile(filename);
    if (!inFile.is_open()) {
        cerr << "Error opening file: " << filename << endl;
        return;
    }

    try {
        json data;
        inFile >> data;

        if (!data.is_array()) {
            cerr << "Invalid JSON format: Expected array of routes" << endl;
            return;
        }

        for (auto& route : data) {
            if (!route.contains("from") || !route.contains("to") || !route.contains("distance") ||
                !route.contains("from_lat") || !route.contains("from_lng") ||
                !route.contains("to_lat") || !route.contains("to_lng")) {
                cerr << "Skipping invalid route: Missing required fields" << endl;
                continue;
            }

            string from = route["from"].get<string>();
            string to = route["to"].get<string>();
            int distance = route["distance"].get<int>();

            // Store coordinates
            cityCoordinates[from] = {route["from_lat"].get<double>(), route["from_lng"].get<double>()};
            cityCoordinates[to] = {route["to_lat"].get<double>(), route["to_lng"].get<double>()};

            // Update adjacency list
            adjList[from].emplace_back(to, distance);
            adjList[to].emplace_back(from, distance);

            // Update adjacency matrix
            adjMatrix[from][to] = distance;
            adjMatrix[to][from] = distance;

            // Initialize traffic data
            trafficData[from][to] = {1.0, "Light", time(nullptr)};
            trafficData[to][from] = {1.0, "Light", time(nullptr)};

            // Ensure cities have indices
            getCityIndex(from);
            getCityIndex(to);
        }
    } catch (const json::exception& e) {
        cerr << "JSON parsing error: " << e.what() << endl;
    }

    inFile.close();
}

// Modified Dijkstra's Algorithm with traffic consideration
pair<vector<string>, int> dijkstraWithTraffic(const string& source, const string& destination) {
    updateTrafficInfo(); // Update traffic info before pathfinding
    
    priority_queue<pair<int, string>, vector<pair<int, string>>, greater<pair<int, string>>> pq;
    unordered_map<string, int> dist;
    unordered_map<string, string> prev;

    for (const auto& city : adjList) {
        dist[city.first] = INT_MAX;
    }

    dist[source] = 0;
    pq.push({0, source});

    while (!pq.empty()) {
        string u = pq.top().second;
        int current_dist = pq.top().first;
        pq.pop();

        if (current_dist > dist[u]) continue;

        for (const auto& neighbor : adjList[u]) {
            string v = neighbor.first;
            int baseWeight = neighbor.second;
            int trafficAdjustedWeight = getTrafficAdjustedDistance(u, v, baseWeight);

            if (dist[v] > dist[u] + trafficAdjustedWeight) {
                dist[v] = dist[u] + trafficAdjustedWeight;
                prev[v] = u;
                pq.push({dist[v], v});
            }
        }
    }

    // Reconstruct path
    vector<string> path;
    if (dist[destination] == INT_MAX) {
        return {path, -1}; // No path exists
    }

    for (string at = destination; at != ""; at = prev[at]) {
        path.push_back(at);
    }
    reverse(path.begin(), path.end());

    return {path, dist[destination]};
}

// Get traffic report for a route
string getTrafficReport(const string& from, const string& to) {
    if (trafficData.find(from) != trafficData.end() && 
        trafficData[from].find(to) != trafficData[from].end()) {
        const auto& info = trafficData[from][to];
        stringstream ss;
        ss << "Traffic condition from " << from << " to " << to << ":\n"
           << "Condition: " << info.condition << "\n"
           << "Delay factor: " << fixed << setprecision(2) << info.factor << "x\n"
           << "Last updated: " << ctime(&info.timestamp);
        return ss.str();
    }
    return "No traffic information available for this route.";
}

// Floyd-Warshall Algorithm with traffic considerations
void initializeFloydWarshall() {
    int n = indexToCity.size();
    distFW.assign(n, vector<int>(n, INT_MAX));
    nextFW.assign(n, vector<string>(n, ""));

    for (int i = 0; i < n; i++) {
        distFW[i][i] = 0;
    }

    for (const auto& from : adjList) {
        int u = getCityIndex(from.first);
        for (const auto& to : from.second) {
            int v = getCityIndex(to.first);
            // Use traffic-adjusted distance
            distFW[u][v] = getTrafficAdjustedDistance(from.first, to.first, to.second);
            nextFW[u][v] = to.first;
        }
    }

    for (int k = 0; k < n; k++) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (distFW[i][k] != INT_MAX && distFW[k][j] != INT_MAX && 
                    distFW[i][j] > distFW[i][k] + distFW[k][j]) {
                    distFW[i][j] = distFW[i][k] + distFW[k][j];
                    nextFW[i][j] = nextFW[i][k];
                }
            }
        }
    }
}

vector<string> getPathFW(const string& start, const string& end) {
    vector<string> path;
    
    if (cityIndices.find(start) == cityIndices.end() || 
        cityIndices.find(end) == cityIndices.end()) {
        return path;
    }

    int u = getCityIndex(start);
    int v = getCityIndex(end);

    if (nextFW[u][v].empty()) {
        return path;
    }

    path.push_back(start);
    string current = start;
    while (current != end) {
        u = getCityIndex(current);
        current = nextFW[u][v];
        path.push_back(current);
    }

    return path;
}

// Modified Prim's Algorithm for MST with traffic considerations
void primMST(const string& startCity) {
    priority_queue<tuple<int, string, string>, 
                   vector<tuple<int, string, string>>, 
                   greater<tuple<int, string, string>>> pq;

    unordered_map<string, bool> inMST;
    mstEdges.clear();

    for (const auto& city : adjList) {
        inMST[city.first] = false;
    }

    inMST[startCity] = true;
    for (const auto& neighbor : adjList[startCity]) {
        int trafficAdjustedWeight = getTrafficAdjustedDistance(startCity, neighbor.first, neighbor.second);
        pq.push(make_tuple(trafficAdjustedWeight, startCity, neighbor.first));
    }

    while (!pq.empty()) {
        int weight = get<0>(pq.top());
        string u = get<1>(pq.top());
        string v = get<2>(pq.top());
        pq.pop();

        if (inMST[v]) continue;

        inMST[v] = true;
        mstEdges.push_back(make_tuple(weight, u, v));

        for (const auto& neighbor : adjList[v]) {
            if (!inMST[neighbor.first]) {
                int trafficAdjustedWeight = getTrafficAdjustedDistance(v, neighbor.first, neighbor.second);
                pq.push(make_tuple(trafficAdjustedWeight, v, neighbor.first));
            }
        }
    }
}

// Modified Travel Plan Optimization with traffic considerations
pair<vector<string>, int> optimizeTravelPlan(const vector<string>& citiesToVisit) {
    if (citiesToVisit.empty()) return {vector<string>(), 0};

    updateTrafficInfo(); // Update traffic before planning

    // Build MST for the subgraph
    primMST(citiesToVisit[0]);

    // Create a map of connections from MST
    unordered_map<string, vector<string>> mstConnections;
    for (const auto& edge : mstEdges) {
        string u = get<1>(edge);
        string v = get<2>(edge);
        mstConnections[u].push_back(v);
        mstConnections[v].push_back(u);
    }

    // Perform DFS on MST to get traversal order
    vector<string> traversalOrder;
    stack<string> s;
    unordered_map<string, bool> visited;

    s.push(citiesToVisit[0]);
    visited[citiesToVisit[0]] = true;

    while (!s.empty()) {
        string current = s.top();
        s.pop();
        traversalOrder.push_back(current);

        for (const string& neighbor : mstConnections[current]) {
            if (!visited[neighbor]) {
                visited[neighbor] = true;
                s.push(neighbor);
            }
        }
    }

    // Connect cities using traffic-aware shortest paths
    vector<string> fullPath;
    int totalDistance = 0;

    for (size_t i = 0; i < traversalOrder.size() - 1; i++) {
        auto result = dijkstraWithTraffic(traversalOrder[i], traversalOrder[i+1]);
        if (result.second == -1) {
            return {vector<string>(), -1};
        }

        for (size_t j = 0; j < result.first.size() - 1; j++) {
            fullPath.push_back(result.first[j]);
        }
        totalDistance += result.second;
    }
    fullPath.push_back(traversalOrder.back());

    return {fullPath, totalDistance};
}

// Utility function to print a path
void printPath(const vector<string>& path, int distance) {
    if (path.empty()) {
        cout << "No path exists!" << endl;
        return;
    }

    cout << "Path: ";
    for (size_t i = 0; i < path.size(); i++) {
        if (i > 0) cout << " -> ";
        cout << path[i];
    }
    cout << "\nTotal distance: " << distance << " units" << endl;
}

// Main menu system
void displayMenu() {
    cout << "\n===== TRAFFIC-AWARE ROUTING SYSTEM =====\n";
    cout << "1. Find shortest path between two cities (Dijkstra)\n";
    cout << "2. Find shortest path between two cities (Floyd-Warshall)\n";
    cout << "3. Optimize travel plan for multiple cities\n";
    cout << "4. Get traffic report for a route\n";
    cout << "5. Update traffic information\n";
    cout << "6. Exit\n";
    cout << "Enter your choice: ";
}

int main() {
    srand(time(nullptr)); // Seed random number generator
    
    // Load the graph data
    loadGraphFromJSON("travel_graph (5).json");
    initializeFloydWarshall();

    int choice;
    string from, to;
    vector<string> citiesToVisit;

    do {
        displayMenu();
        cin >> choice;
        cin.ignore(); // Clear newline character

        switch (choice) {
            case 1: {
                cout << "Enter starting city: ";
                getline(cin, from);
                cout << "Enter destination city: ";
                getline(cin, to);
                
                auto result = dijkstraWithTraffic(from, to);
                printPath(result.first, result.second);
                break;
            }
            case 2: {
                cout << "Enter starting city: ";
                getline(cin, from);
                cout << "Enter destination city: ";
                getline(cin, to);
                
                vector<string> path = getPathFW(from, to);
                int distance = distFW[getCityIndex(from)][getCityIndex(to)];
                printPath(path, distance);
                break;
            }
            case 3: {
                citiesToVisit.clear();
                int numCities;
                cout << "Enter number of cities to visit: ";
                cin >> numCities;
                cin.ignore();
                
                for (int i = 0; i < numCities; i++) {
                    string city;
                    cout << "Enter city #" << i+1 << ": ";
                    getline(cin, city);
                    citiesToVisit.push_back(city);
                }
                
                auto result = optimizeTravelPlan(citiesToVisit);
                printPath(result.first, result.second);
                break;
            }
            case 4: {
                cout << "Enter starting city: ";
                getline(cin, from);
                cout << "Enter destination city: ";
                getline(cin, to);
                
                cout << getTrafficReport(from, to) << endl;
                break;
            }
            case 5: {
                updateTrafficInfo();
                cout << "Traffic information updated successfully!" << endl;
                break;
            }
            case 6: {
                cout << "Exiting program..." << endl;
                break;
            }
            default: {
                cout << "Invalid choice. Please try again." << endl;
            }
        }
    } while (choice != 6);

    return 0;
}
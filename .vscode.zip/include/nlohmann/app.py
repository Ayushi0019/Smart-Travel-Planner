from flask import Flask, request, jsonify
import subprocess

app = Flask(__name__)

@app.route('/api/route', methods=['POST'])
def route():
    data = request.json

    start = data['start'].replace(" ", "_")
    end = data['end'].replace(" ", "_")

    # Write input file for C++
    with open("input.txt", "w") as f:
        for city in data['cities']:
            f.write(f"{city['name']} {city['lat']:.4f} {city['lng']:.4f}\n")
        for route in data['routes']:
            f.write(f"{route['from']} {route['to']} {route['distance']}\n")
        f.write("\n")  # blank line to indicate end of graph
        f.write(f"{start} {end}\n")

    # Run the compiled main.exe with input.txt
    result = subprocess.run(["./main.exe"], input=open("input.txt").read(), capture_output=True, text=True)

    if result.returncode != 0:
        return jsonify({"error": result.stderr})

    output_path = result.stdout.strip().split()
    return jsonify({
        "path": output_path,
        "distance": 0  # optional: calculate distance inside C++
    })

if __name__ == '__main__':
    app.run(debug=True)
